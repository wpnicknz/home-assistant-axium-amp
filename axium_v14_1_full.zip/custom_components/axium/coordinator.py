from __future__ import annotations
import asyncio
import logging
from datetime import timedelta
import aiohttp

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import AxiumApi

_LOGGER = logging.getLogger(__name__)

def encode_zone(zone: int) -> str:
    z = zone
    if z != 0xFF:
        if z >= 64:
            z = 0xC0 + (z - 64)
        elif z >= 32:
            z = 0x80 + (z - 32)
    return f"{z:02X}"

def decode_zone(z_hex: str) -> int | None:
    try:
        z = int(z_hex, 16)
    except ValueError:
        return None
    if z != 0xFF:
        z &= ~0x20
        top = z & 0xC0
        if top == 0x80:
            return 32 + (z & 0x1F)
        if top == 0xC0:
            return 64 + (z & 0x1F)
        if top == 0x40:
            return None
    return z

DECODE_SOURCE_MAP = {0: 4, 1: 5, 2: 6, 3: 3, 4: 7, 5: 0, 6: 1, 7: 2}
ENCODE_SOURCE_MAP = {v: k for k, v in DECODE_SOURCE_MAP.items()}

class AxiumCoordinator(DataUpdateCoordinator):
    def __init__(self, hass: HomeAssistant, session: aiohttp.ClientSession, host: str, zones: list[int], scan_interval: int):
        super().__init__(hass, _LOGGER, name="axium", update_interval=timedelta(seconds=scan_interval))
        self.hass = hass
        self.api = AxiumApi(session, host)
        self.zones = zones
        self.power: dict[int, str | None] = {z: None for z in zones}
        self.volume: dict[int, int | None] = {z: None for z in zones}
        self.source: dict[int, int | None] = {z: None for z in zones}
        self.max_vol: dict[int, int | None] = {z: 0xA0 for z in zones}
        self.source_names: dict[int, dict[int, str]] = {z: {} for z in zones}
        self._lp_task: asyncio.Task | None = None

        self.zone_group: dict[int, int | None] = {z: None for z in zones}
        self.group_options: dict[int, int] = {}

    def _linked_peers(self, zone: int) -> list[int]:
        g = self.zone_group.get(zone)
        if g is None:
            return []
        return [z for z, gz in self.zone_group.items() if gz == g and z != zone]

    async def _async_update_data(self):
        _LOGGER.debug("Manually updated axium data")
        return {
            "power": self.power,
            "volume": self.volume,
            "source": self.source,
            "max_vol": self.max_vol,
            "source_names": self.source_names,
        }

    async def async_config_entry_first_refresh(self):
        for z in self.zones:
            try:
                text = await self.api.snapshot_burst(encode_zone(z))
                for line in text.replace("\r", "").split("\n"):
                    line = line.strip()
                    if line:
                        _LOGGER.debug("SNAPSHOT RX: %s", line)
                        self._handle_frame(line)
            except Exception as e:
                _LOGGER.debug("Snapshot burst failed for zone %s: %s", z, e)

        await super().async_config_entry_first_refresh()

        if self._lp_task is None:
            self._lp_task = self.hass.loop.create_task(self._longpoll_loop())

    async def _longpoll_loop(self):
        while True:
            try:
                if self.api._session.closed:
                    self.api._session = async_get_clientsession(self.hass)
                resp = await self.api.open_longpoll()
                try:
                    async for chunk, _ in resp.content.iter_chunks():
                        if not chunk:
                            continue
                        text = chunk.decode(errors="ignore")
                        for line in text.replace("\r", "").split("\n"):
                            line = line.strip()
                            if line:
                                _LOGGER.debug("RX: %s", line)
                                self._handle_frame(line)
                finally:
                    await resp.release()
            except Exception as e:
                _LOGGER.debug("Long-poll error, retrying: %s", e)
                await asyncio.sleep(1)

    def _handle_frame(self, line: str):
        if len(line) < 4:
            return
        cmd = line[:2].upper()
        zone_raw = line[2:4].upper() if len(line) >= 4 else None
        z = decode_zone(zone_raw) if zone_raw else None
        data = line[4:].upper()

        try:
            if cmd == "01" and len(data) >= 2:
                if z is None: return
                d = data[:2]
                if d in ("01", "07"):
                    self.power[z] = "on"
                elif d in ("00", "06"):
                    self.power[z] = "off"
                g = self.zone_group.get(z)
                if g is not None and (self.group_options.get(g, 0) & 0x04):
                    for peer in self._linked_peers(z):
                        self.power[peer] = self.power.get(z)

            elif cmd == "03" and len(data) >= 2:
                if z is None: return
                val = int(data[:2], 16)
                if val & 0x80:
                    self.power[z] = "on"
                    val &= 0x1F
                decoded = DECODE_SOURCE_MAP.get(val, val)
                self.source[z] = decoded
                g = self.zone_group.get(z)
                if g is not None and (self.group_options.get(g, 0) & 0x01):
                    for peer in self._linked_peers(z):
                        self.source[peer] = self.source.get(z)

            elif cmd == "04" and len(data) >= 2:
                if z is None: return
                self.volume[z] = int(data[:2], 16)
                g = self.zone_group.get(z)
                if g is not None and (self.group_options.get(g, 0) & 0x02):
                    for peer in self._linked_peers(z):
                        self.volume[peer] = self.volume.get(z)

            elif cmd == "0D" and len(data) >= 2:
                if z is None: return
                self.max_vol[z] = int(data[:2], 16)

            elif cmd == "29" and len(data) >= 2:
                enc_src = int(data[:2], 16)
                norm = DECODE_SOURCE_MAP.get(enc_src, enc_src)
                raw_name_hex = data[8:] if len(data) >= 8 else ""
                try:
                    name = bytes.fromhex(raw_name_hex).decode(errors="ignore").strip()
                except Exception:
                    name = None
                if name:
                    targets = (self.zones if (z == 255 or z is None) else [z])
                    changed = False
                    for _zz in targets:
                        prev = self.source_names.setdefault(_zz, {}).get(norm)
                        if prev != name:
                            self.source_names[_zz][norm] = name
                            changed = True
                    if changed:
                        _LOGGER.debug("SRCNAME parsed: zone=%s enc=%s norm=%s name=%s", z, enc_src, norm, name)

            elif cmd == "30" and len(data) >= 2:
                try:
                    opts = int(data[:2], 16)
                    preamble_bytes = 5 if (opts & 0x80) else 1
                    rest = data[2 * preamble_bytes : ]
                    zones = []
                    for i in range(0, len(rest), 2):
                        zz = rest[i:i+2]
                        if len(zz) < 2: break
                        dz = decode_zone(zz)
                        if dz is not None:
                            zones.append(dz)
                    for dz in zones:
                        self.zone_group[dz] = None
                    used = set(g for g in self.zone_group.values() if g is not None)
                    spare = next((g for g in range(48) if g not in used), None)
                    if spare is not None and len(zones) > 1:
                        self.group_options[spare] = opts
                        for dz in zones:
                            self.zone_group[dz] = spare
                except Exception:
                    pass
        except Exception as e:
            _LOGGER.debug("Frame parse error for '%s': %s", line, e)

        self.async_set_updated_data({
            "power": self.power,
            "volume": self.volume,
            "source": self.source,
            "max_vol": self.max_vol,
            "source_names": self.source_names,
        })
