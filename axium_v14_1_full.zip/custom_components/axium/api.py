from __future__ import annotations
import aiohttp
from .const import HTTP_URL, HEADERS

class AxiumApi:
    def __init__(self, session: aiohttp.ClientSession, host: str):
        self._session = session
        self._host = host
        self._url = HTTP_URL.format(host=host)

    async def send(self, code: str) -> str:
        payload = f"{code}\r\n"
        async with self._session.post(self._url, headers=HEADERS, data=payload) as resp:
            return await resp.text()

    async def snapshot_burst(self, zone_hex: str) -> str:
        burst = (
            f"30{zone_hex}\r\n01{zone_hex}\r\n02{zone_hex}\r\n03{zone_hex}\r\n"
            f"04{zone_hex}\r\n29{zone_hex}\r\n3C{zone_hex}\r\n0D{zone_hex}\r\n"
        )
        async with self._session.post(self._url, headers=HEADERS, data=burst) as resp:
            return await resp.text()

    async def open_longpoll(self):
        url = self._url.replace("/axium.cgi", "/axiumlong.cgi")
        return await self._session.get(url)
